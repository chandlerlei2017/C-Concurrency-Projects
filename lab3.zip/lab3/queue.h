#include <stdio.h>
#include <stdlib.h>

typedef struct recv_buf_flat {
    char *buf;       /* memory to hold a copy of received data */
    size_t size;     /* size of valid data in buf in bytes*/
    size_t max_size; /* max capacity of buf in bytes*/
    int seq;         /* >=0 sequence number extracted from http header */
                     /* <0 indicates an invalid seq number */
} RECV_BUF;

// Data structure for queue
struct queue
{
  int head;
  int tail;
  int curr_size;
  int max_size;

  RECV_BUF* buffer;
};




